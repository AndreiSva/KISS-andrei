#ifndef NVIM_EX_SESSION_H
#define NVIM_EX_SESSION_H

#include <stdio.h>

#include "nvim/ex_cmds_defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "ex_session.h.generated.h"
#endif

#endif  // NVIM_EX_SESSION_H

