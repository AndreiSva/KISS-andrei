#ifndef NVIM_MOVE_H
#define NVIM_MOVE_H

#include <stdbool.h>
#include "nvim/vim.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "move.h.generated.h"
#endif
#endif  // NVIM_MOVE_H
