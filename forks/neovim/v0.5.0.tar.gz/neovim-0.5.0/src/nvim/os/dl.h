#ifndef NVIM_OS_DL_H
#define NVIM_OS_DL_H

#include <stdbool.h>
#include <stdint.h>

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "os/dl.h.generated.h"
#endif
#endif  // NVIM_OS_DL_H
