#ifndef NVIM_MATH_H
#define NVIM_MATH_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "math.h.generated.h"
#endif
#endif  // NVIM_MATH_H
